# ** coding: utf-8 **
"""
@Author: Zhihong Li, Rongrong Lin
@date: 2024/12/19
@description: Proximal operators for L1\psi
@version: 1.0
"""
from typing import Union

import numpy as np

from prox import GroupProximalOperator
from prox.sep_prox.prox_cl import *
from abc import ABCMeta
from prox import ProximalOperator


class L1_SubvecProx(metaclass=ABCMeta):
    # con1: T = None
    # con2: T = None
    # con4: T = None
    precompute: bool


    __slots__ = ['tau_nv_psi', 'precompute', 's_arange', 'gLen', 'element_prox', 'zeros', 'lamb']

    def __init__(self, gLen, lamb: T, element_prox: ProximalOperator):
        self.s_arange = None
        self.gLen = gLen
        self.lamb = lamb
        self.element_prox = element_prox
        self.zeros = np.zeros(gLen)
        self.s_arange = np.arange(1, gLen + 1)
        self.tau_nv_psi = None

    def calculate_tau_nv_psi(self, *args, **kwargs) -> Union[T, int, float, np.ndarray]:
        raise NotImplementedError


    def obj(self, y: np.ndarray, ytilde: np.ndarray, lamb: T) -> np.ndarray:
        """
        Object function for L1\psi, such as : lamb*\|y\|_1+0.5*\|y-ytilde\|_2^2
        :param y:
        :param ytilde:
        :param lamb:
        :return:
        """
        raise NotImplementedError

    def prox(self, x, v):
        self.lamb = v
        tau_nv_psi = self.compute_conditions(v)

        x_abs = np.abs(x)
        ys_l1 = x_abs.sum()

        # if ys_l1 <= con1:
        #     return self.zeros
        if np.linalg.norm(x, ord=2) <= tau_nv_psi:
            return self.zeros
        else:
            sign_x = np.sign(x)
            indices = np.argsort(-x_abs)
            y = x_abs[indices]
            if y[-1] > tau_nv_psi:
                return (x_abs - self._calculate_cs(y_l1_array=ys_l1, nu=v, s=self.gLen)) * sign_x
            else:
                sorted_indices = np.argsort(indices)
                s_list = [self.zeros]
                s_list.extend(self._loop_search_s(y, v, tau_nv_psi))
                Js_list = [self.obj(y, per_ytilde, v) for per_ytilde in s_list]
                return self._rearrange_org(s_list[np.argmin(Js_list)], sorted_indices, sign_x)

    def name(self) -> str:
        return self.element_prox.name()

    @staticmethod
    def _rearrange_org(ytilde: np.ndarray, sorted_indices, sign: np.ndarray) -> np.ndarray:
        return ytilde[sorted_indices] * sign

    def _calculate_cs(self, y_l1_array: np.ndarray, nu: np.ndarray, s) -> np.ndarray:
        return self.lamb * (self.element_prox.calculate_subderivative(
            self.element_prox.prox(y_l1_array, v=nu * s))
        )

    def _loop_search_s(self, y, nu, con4):
        y_l1_array = y.cumsum()
        cs_array = self._calculate_cs(y_l1_array, nu, self.s_arange)  # y -> y_s
        y_plus = np.concatenate((y[1:], [-1]))
        res = (y_l1_array > con4) & (y > cs_array) & (cs_array >= y_plus)
        return [np.maximum(y - cs_array[ind], 0) for ind in np.where(res)[0]]

    def compute_conditions(self, v):
        if self.precompute is True or v == self.lamb and self.tau_nv_psi is not None:
            tau_nv_psi = self.tau_nv_psi
        else:
            tau_nv_psi = self.calculate_tau_nv_psi(v)
        return tau_nv_psi


class GeneralProxL1Psi(GroupProximalOperator):

    def __init__(self, n: int, gLen: int, subvec_prox: L1_SubvecProx, num_samples: int = 1):
        self.n: int = n
        self.gLen: int = gLen
        self.num_subvectors: int = self.get_num_subvectors(n, gLen)
        self.subvec_prox: L1_SubvecProx = subvec_prox
        self.num_samples: int = num_samples

    def prox(self, x: np.ndarray, v, *args, **kwargs) -> np.ndarray:
        x_subvectors = self._split_vectors(x)
        subvec_prox = self.subvec_prox
        return self._concentrate_vectors([subvec_prox.prox(x_sub, v) for x_sub in x_subvectors]).reshape(
            self.num_samples, -1)

    def name(self):
        return self.subvec_prox.name()

    def _split_vectors(self, x: np.ndarray) -> list[np.ndarray]:
        return np.split(x.flatten(), self.num_subvectors * self.num_samples)

    @classmethod
    def _concentrate_vectors(self, x_subvectors: list[np.ndarray]) -> np.ndarray:
        return np.concatenate(x_subvectors)


class GeneralProxL2Psi(GroupProximalOperator):

    def __init__(self, n: int, gLen: int, subvec_prox: ProximalOperator):
        self.n: int = n
        self.gLen: int = gLen
        self.num_subvectors: int = self.get_num_subvectors(n, gLen)
        self.subvec_prox: ProximalOperator = subvec_prox


    def prox(self, x: np.ndarray, v, *args, **kwargs) -> np.ndarray:
        x_subvectors = self._split_vectors(x)

        norms = np.stack([np.linalg.norm(subvec, ord=2, axis=1) for subvec in x_subvectors], axis=0)

        tao = self.subvec_prox.prox(norms, v) / (norms)
        x_subvectors = [tao[i].reshape(-1, 1) * x_subvectors[i] for i in range(self.num_subvectors)]
        return self._concentrate_vectors(x_subvectors)

    def name(self):
        return self.subvec_prox.name()

    def _split_vectors(self, x: np.ndarray) -> list[np.ndarray]:
        return np.split(x, self.num_subvectors, axis=1)

    @staticmethod
    def _concentrate_vectors(x_subvectors: list[np.ndarray]) -> np.ndarray:
        return np.concatenate(x_subvectors, axis=1)
